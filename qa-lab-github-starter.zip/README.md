# QA Lab – GitHub + Pages

Petit projet pour le laboratoire d’assurance qualité logiciel.

- **Auteur** : Hanane Khenteur
- **Licence** : MIT (voir fichier `LICENSE`)

## Site web (GitHub Pages)
➡️ Le site sera publié ici : **(ajoute le lien quand GitHub Pages sera activé)**

## Contenu
- `index.html` : page d’accueil avec mon nom
- `LICENSE` : licence MIT
- `README.md` : description rapide du projet
